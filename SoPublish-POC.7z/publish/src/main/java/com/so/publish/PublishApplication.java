package com.so.publish;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
/**
 * 
 * @author Mohan K - AL2428
 *
 */
@SpringBootApplication
public class PublishApplication {
	public static void main(String[] args) {
		SpringApplication.run(PublishApplication.class, args);
	}
}
